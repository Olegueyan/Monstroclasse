package net.olegueyan.monstroclasse.json.ecritoire;

import com.google.gson.annotations.SerializedName;

public class EcritoireColumnSpecs
{
    @SerializedName("scol")
    public int scol;

    @SerializedName("tone")
    public int tone;
}